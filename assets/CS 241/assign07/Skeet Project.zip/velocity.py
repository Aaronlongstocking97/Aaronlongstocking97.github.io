"""
 Program:
    CS241 Assignment 07, Skeet Project
 Instructor:
    Borther Macbeth
 Author:
    Aaron Jones
 Summary: 
    This class will set the intial state values
    for both x and y velocities. It will also be
    passed through multiple class with a "Has - A"
    relationship and give the default values as
    listed below. 
    
"""

"""
* 
"""
class Velocity:

    def __init__(self):
        self.dx = 0.0
        self.dy = 0.0
